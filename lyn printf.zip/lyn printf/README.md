# Custom Printf program by Lynn and Moses

The code written here creates a custom printf function named _printf